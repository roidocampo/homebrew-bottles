#ifndef __cplusplus   
/*BEWARE: this fix can lead to problems if cf_gmp.h is publicly installed, while mixing different (versions of) compilers!!!*/
#define __cplusplus 199711L
#endif /*__cplusplus*/
