/*
4ti2 -- A software package for algebraic, geometric and combinatorial
problems on linear spaces.

Copyright (C) 2006 4ti2 team.
Main author(s): Peter Malkin.

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA. 
*/

#ifndef _4ti2__CircuitOptions_
#define _4ti2__CircuitOptions_
#include <string>

namespace _4ti2_
{

class CircuitOptions
{
public:
    typedef enum {MATRIX, SUPPORT} Algorithm;
    typedef enum {MAXINTER, MININDEX, MAXCUTOFF, MINCUTOFF} NextColumn;
    typedef enum {VERBOSE, SILENT} Output;

    Algorithm algorithm;
    NextColumn next_column;
    Output output;
    std::string filename;

    void process_options(int argc, char **argv);

    static CircuitOptions* instance();

protected:
    CircuitOptions();
    void unrecognised_option_argument(const char* option);
    static CircuitOptions* o;
    void print_usage();
};

} // namespace _4ti2_

#endif
