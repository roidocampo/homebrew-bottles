/* $Id: parierr.h,v 1.5 1999/11/18 13:25:56 karim Exp $ */
enum {
  caracer1, caseer, caseer2, member, nparamer1,
  paramer1, varer1, obsoler, openfiler, talker2,

/* NO CONTEXT now */

  talker, flagerr, warner, warnprec, warnfile,
  accurer, bugparier, impl, archer, warnmem,

  siginter, typeer, consister,

/* mp.s ou mp.c */

  affer1, affer2, affer3, affer4, affer5,
  shier1, shier2, truer1, truer2, adder1,
  
  adder2, adder3, adder4, adder5, muler1,
  muler2, muler3, muler4, muler5, muler6,
  diver1, diver2, diver3, diver4, diver5,
  diver6, diver7, diver8, diver9, diver10,
  diver11, diver12, divzer1, dvmer1, moder1,
  
  reser1, arier1, arier2, errpile, errlg,
  errlgef, errexpo, errvalp, rtodber,

/* alglin.c */

  concater, matinv1, mattype1, suppler2,

/* anal.c   */

  valencer1, breaker,

/* arith.c  */

  arither1, arither2, facter, hiler1, funder2,
  generer, primer1,

/* base.c   */
  polrationer, constpoler, notpoler, redpoler, zeropoler,
  idealer1, idealer2, idealer5,

/* bibli.c  */

  changer1, intger2, lllger3, lllger4,

/* elliptic.c */

  elliper1, heller1,

/* gen.c */
  operi, operf, gdiver2, inter2, overwriter,

/* init.c */

  memer, gerper,

/* plot.c */

  ploter4, ploter5,

/* polarit.c */

  poler9, rootper1, rootper2, rootper4,

/* trans.c */

  infprecer, negexper, sqrter5, sqrter6, gamer2,
  thetaer1,

/* PAS D'ERREUR */

  noer
};
