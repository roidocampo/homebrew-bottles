/*  This file was created by Configure. Any change made to it will be lost
 *  next time Configure is run.
 */
#ifndef __CONFIG_H__
#define __CONFIG_H__
#define UNIX
#define GPHELP "@@HOMEBREW_CELLAR@@/asir/20160320/libexec/bin/gphelp"
#define GPDATADIR "@@HOMEBREW_CELLAR@@/asir/20160320/libexec/lib/pari/data"
#define SHELL_Q '\''

#define PARIVERSION "GP/PARI CALCULATOR Version 2.0.21 (beta)"
#ifdef __cplusplus
# define PARIINFO "C++ unknown 64-bit version"
#else
# define PARIINFO "unknown 64-bit version"
#endif

#define PARI_BYTE_ORDER    12345678
#define __HAS_NO_ASM__

/*  Location of GNU gzip program (enables reading of .Z and .gz files). */
#define GNUZCAT
#define ZCAT "/usr/bin/gzip -dc"

#define LONG_IS_64BIT
#define ULONG_NOT_DEFINED
#define USE_GETRUSAGE 1
#define USE_SIGRELSE 1
#define HAS_DLOPEN
#define DL_DFLT_NAME "libpari."
#define HAS_TIOCGWINSZ
#define HAS_STRFTIME
#endif
